package hemant.com;
//how to define a class & field( data members / variable)
public class JavaBatch {
	//defining fields(Instance variable)
	int id;
	String name;
	public static void main(String[] args) {
		// create object
		JavaBatch jb=new JavaBatch();
		//JavaBatch jb1=new JavaBatch();
		// Print value
		jb.id=1;
		jb.name="Hemant";
		System.out.println("Id is : "+jb.id + " " +"name is: "+jb.name );
		jb.id=2;
		jb.name="Aman";
		System.out.println("Id is : "+jb.id + " " +"name is: "+jb.name );
	}

}
