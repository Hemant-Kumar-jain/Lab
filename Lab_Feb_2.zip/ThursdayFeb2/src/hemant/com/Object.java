package hemant.com;

//3 ways to initialize object in java - By reference variable , by method , by constructor
class ObjectEg {
	// Instance variable
	int id=101;
	String name="Hemant";
}

class Object{
	public static void main(String[] args) {
		ObjectEg obj=new ObjectEg(); // Create object -- obj is our reference variable
		//obj.id=101;
		//obj.name="Hemant";
		System.out.println("Id is : "+obj.id +"\n"+"Name is : "+obj.name); // Printing members with white Spaces
	}
	

}
