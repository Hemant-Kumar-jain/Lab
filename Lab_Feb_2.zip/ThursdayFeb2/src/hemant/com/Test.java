package hemant.com;
import java.util.Scanner; // import Scanner Class

public class Test { // Declare a Class
	public static void main(String[] args) {// Declare a main method
		int num;
		int sum=0;
		Scanner sc=new Scanner(System.in);
		for(int i=1;i<=5;i++) {  
			switch(i) {
			case 1: System.out.println("Input first Number");
					num=sc.nextInt();
					break;
			case 2: System.out.println("Input second Number");
					num=sc.nextInt();
					break;
			case 3: System.out.println("Input third Number");
					num=sc.nextInt();
					break;
			case 4: System.out.println("Input fourth Number");
					num=sc.nextInt();
					break;
			case 5: System.out.println("Enter fifth Number");
					num=sc.nextInt();
					break;
			default:System.out.println("Enter Right Input");
					break;
					sum+=num;
			}
			
		}
		
	}

}
