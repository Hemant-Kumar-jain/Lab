package hemant.com;

public class Test2 {
	public static void main(String[] args) {
		int a=5;
		int b=8;
		int c;
		// Before Swapping
		System.out.println("Before Swapping A is: "+a);
		System.out.println("Before Swapping B is: "+b);
		// Swapping the values 
		c=a;
		a=b;
		b=c;
		//After Swapping a=8 & b=5
		System.out.println("After Swapping A is: "+a);
		System.out.println("After Swapping B is: "+b);
	}
}
